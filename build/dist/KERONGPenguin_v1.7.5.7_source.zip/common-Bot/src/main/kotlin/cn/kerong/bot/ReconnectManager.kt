package cn.kerong.bot

import cn.kerong.bot.tools.PluginFileLog
import io.github.kloping.qqbot.api.v2.GroupMessageEvent
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * 机器人重连编排器。
 *
 * ## 背景
 *
 * 旧版（≤1.6.1）的断线处理：
 * - SDK 自身 anyCloseReconnect 任意关闭码 3 秒后自动重连——重连过程对控制台完全静默，
 *   管理员只看到反复的连接日志，不知道机器人正在重试、重试了几次、
 *   还会不会继续重试；
 *
 * ## 新行为
 *
 * 1. **重试里程碑可见**：控制台只在关键节点输出——本轮第 1 次重试、
 *    最后一次重试、重连成功、重连超时；中间几次的过程提示只写插件日志文件
 *    （1.6.6.3：网络抖动 / 平台网关异常引起的重连风暴不再刷屏控制台，
 *    完整过程日志仍在 logs/qq/qq-bind-日期.log 里可追溯）；
 * 2. **每轮最多 5 次**：连续 5 次重连失败（连接打开但未存活到健康阈值又被关闭）
 *    则暂时放弃自动重连，输出「重连超时」提示：可使用指令 /hbkrg chs 立即手动重试，
 *    或等待 30 分钟后自动进行下一轮（最多 3 轮）；
 * 3. **手动重试**：/hbkrg chs 重置全部计数并立即恢复连接（也可在 30 分钟退避期间随时使用）。
 *
 * ## 1.7.2 手动重连过程回显 QQ 群
 *
 * 用户在 QQ 群里远程执行重连（/执行命令 hbkrg chs）后，旧版 QQ 回复只有
 * 一句「连接过程与结果见控制台」——过程只在控制台，远程操作的人看不到：
 * 手动重连触发的一轮内，关键里程碑（第 1 次 / 最后一次重试、成功、超时）
 * 同时发送到配置的 QQ 群；断线期间发送失败的行自然丢弃（不补发），
 * 成功 / 超时结果在连接恢复后必达。自动重连与首次启动不广播（不打扰群）。
 *
 * ## 计数模型
 *
 * - 每次 WebSocket 连接打开（[onOpen]）= 一次重试尝试（首次启动连接也计入，
 *   启动失败同样受 5 次上限保护，防止凭据错误时无限刷屏重连）；
 * - 「健康」= READY/RESUMED 鉴权成功且存活 ≥ 90 秒：健康会话把 attempt / bigRound 全部清零；
 * - 「失败」= 连接未健康存活即被关闭：SDK 将自动发起下一次重连（attempt 继续 +1）；
 * - attempt ≥ 5 时的关闭 → 触发 [giveUpAutoReconnect]（挂起 SDK 自动重连 + 退避）。
 * - 1.6.6.3：重连超时挂起后，SDK 已排队的延迟重连（无法从外部取消）仍可能
 *   打开新连接，此时计数已达上限——按新一轮重新计数（避免「第 6/5 次」
 *   越界显示；该连接若恢复健康会正常宣告成功并解除挂起）。
 *
 * ## 1.6.6.3：移除双服同绑检测
 *
 * 旧版（1.6.1~1.6.6.2）的「同 AppID 多连接互踢 / 双服务器抢占」检测在
 * 平台网关抖动（会话无效 op 9、create session error、网关踢线）导致的
 * 重连风暴中会误判为「另一台服务器绑定了同一个机器人」——实际只有一台
 * 服务器在连接。误报提示对排查毫无帮助反而误导管理员，故整体移除：
 * 连接层不再做任何冲突推断，重连风暴按其本来面目（网络 / 平台问题）
 * 记录与重试。
 *
 * 状态读取集中在 [WssDiagnostics] 的回调与看门狗线程，全部为 volatile /
 * AtomicInteger 写，无锁。
 */
object ReconnectManager {

    /** 每轮自动重试的最大次数（用户需求：共重试 5 次）。 */
    const val SMALL_RETRY_MAX = 5

    /** 大轮次上限（30 分钟一轮，最多 3 轮自动重试）。 */
    const val BIG_ROUND_MAX = 3

    /** 两轮之间的退避时长（30 分钟）。 */
    private const val BIG_BACKOFF_MILLIS = 30L * 60L * 1000L

    /** 会话「健康存活」阈值（毫秒，READY 后存活达到即视为成功恢复）。 */
    internal const val HEALTHY_SESSION_MS = 90_000L

    /** 当前小轮已尝试的重连次数（连接打开即 +1）。 */
    private val attempt = AtomicInteger(0)

    /** 已消耗完的退避大轮次数（0 = 未进入过退避）。 */
    private val bigRound = AtomicInteger(0)

    /** 挂起代际号（每次 giveUp / 手动重置自增；旧退避线程醒来时据此判断自己是否已过期）。 */
    private val generation = AtomicInteger(0)

    /** 是否已挂起 SDK 自动重连（重连超时后 true，恢复重连或重连成功后 false）。 */
    @Volatile
    private var suspended = false

    /** 最近一次连接打开的时间戳（用于健康判定）。 */
    @Volatile
    private var lastOpenAt = 0L

    /** 是否已输出过「重连成功」（本轮内去重，防止看门狗反复清零时重复提示）。 */
    @Volatile
    private var successAnnounced = false

    /** 1.6.5：自本次启动以来是否发生过连接关闭（区分「首次连接」与「重连」：首次连接另有启动日志，不该报「重连成功」）。 */
    @Volatile
    private var hadAnyClose = false

    /** 1.6.5：上一条会话是否短命（短命会话后的 READY 不立即宣告成功，避免风暴场景成功/失败提示来回抖动）。 */
    @Volatile
    private var lastSessionShort = false

    /**
 * 本轮是否把重连过程回显到 QQ 群——仅手动重连（/hbkrg chs）
     * 触发的一轮内开启；成功或超时挂起后关闭，自动重连与首次启动不广播。
     */
    @Volatile
    private var announceToGroups = false

    /** 当前重连尝试次数（第 N 次（1/5））。 */
    fun currentAttempt(): Int = attempt.get()

    /** 是否处于挂起状态（SDK 自动重连已关闭，等待退避或手动重试）。 */
    fun isSuspended(): Boolean = suspended

    /**
 * 把重连过程里程碑发送到配置的 QQ 群（手动重连回显）。
     * 尽力而为：连接断开期间发送失败自然丢弃，不影响重连流程本身。
     */
    private fun announceToGroup(line: String) {
        if (!announceToGroups) return
        try {
            QClient.broadcastReconnectLine(PluginFileLog.stripColorCodes(line))
        } catch (_: Throwable) {
        }
    }

    // ---------- 回调（由 WssDiagnostics / QClient 调用） ----------

    /** 客户端启动：全部状态复位。 */
    fun onLaunch() {
        attempt.set(0)
        bigRound.set(0)
        suspended = false
        successAnnounced = false
        lastOpenAt = 0L
        hadAnyClose = false
        lastSessionShort = false
        announceToGroups = false
    }

    /**
     * WebSocket 连接打开（SDK 首次连接或自动重连的每一次）。
     *
     * 计入本轮第 N 次；控制台只输出本轮第 1 次与最后一次（中间过程写文件，
     * 防重连风暴刷屏；`bot.reconnect-notify` 关闭时第 1 次也不输出——
     * 最后一次与成功/失败提示始终输出）。
     *
 * 计数已达上限时又开新连接（SDK 已排队的延迟重连无法从外部
     * 取消，挂起后 3 秒仍会触发一次）——按新一轮重新计数，
     * 修复「第 6/5 次」越界显示。
     */
    fun onOpen() {
        lastOpenAt = System.currentTimeMillis()
        successAnnounced = false
        if (attempt.get() >= SMALL_RETRY_MAX) {
            // 挂起后 SDK 已排队的延迟重连照常建连：视为新一轮开始重新计数
            attempt.set(0)
        }
        val n = attempt.incrementAndGet()
        if (n == 1) {
            if (notifyEnabled()) {
                val line = "[重连] 第 $n/$SMALL_RETRY_MAX 次重试连接…（连接已打开，等待鉴权）"
                PluginFileLog.infoAndKeep(line)
                announceToGroup(line)
            }
        } else if (n == SMALL_RETRY_MAX) {
            val line = "[重连] 第 $n/$SMALL_RETRY_MAX 次重试连接…（本轮最后一次自动重连）"
            PluginFileLog.infoAndKeep(line)
            announceToGroup(line)
        } else if (notifyEnabled()) {
            // 中间过程：仅文件留档，不刷控制台；QQ 群回显同样只发里程碑
            PluginFileLog.write("[重连] 第 $n/$SMALL_RETRY_MAX 次重试连接…（连接已打开，等待鉴权）")
        }
    }

    /**
     * READY / RESUMED 到达：本次尝试鉴权成功。
     *
 * 修复「部分重连成功没有提示」：现改在鉴权完成（READY/RESUMED）时即宣告成功；
     * 仅当上一条会话是短命会话（风暴抖动特征）时保持旧版沉默策略，等 90 秒健康判定兜底，
     * 避免风暴场景下成功/失败提示来回刷屏。
     */
    fun onSessionReady() {
        if (hadAnyClose && !lastSessionShort && !successAnnounced && attempt.get() > 0) {
            val line = "[重连] QQ 机器人重连成功（第 ${attempt.get()}/$SMALL_RETRY_MAX 次尝试），消息收发已恢复"
            PluginFileLog.infoAndKeep(line)
            announceToGroup(line)
            successAnnounced = true
            // 计数器不在此清零：短命会话仍按 5 次上限计数（防重连风暴），
            // 健康判定（存活≥90 秒）达成后再统一清零；
            // QQ 群回显到成功即止（后续健康判定不再重复发群）
            announceToGroups = false
        }
    }

    /**
     * 会话健康存活（READY 后存活 ≥ [HEALTHY_SESSION_MS]，或关闭时存活达到阈值）。
     * 重置全部计数并宣告「重连成功」（成功提示一句话，不属防刷屏范围）。
     */
    fun onHealthySession() {
        if (hadAnyClose && !successAnnounced && attempt.get() > 0) {
            val line = "[重连] QQ 机器人重连成功（第 ${attempt.get()}/$SMALL_RETRY_MAX 次尝试），消息收发已恢复"
            PluginFileLog.infoAndKeep(line)
            announceToGroup(line)
        }
        successAnnounced = true
        lastSessionShort = false
        attempt.set(0)
        bigRound.set(0)
        suspended = false
        announceToGroups = false
    }

    /**
     * 连接被关闭时回调（在关闭时刻由 [WssDiagnostics.onClose] 调用）。
     *
     * @param survivedMs 本次会话 READY 后的存活毫秒数（0 = 未能完成鉴权）
     * @param healthy 是否达到健康存活阈值（达到则视为一次成功恢复，随后又开始新一轮）
     * @return 是否已触发「重连超时」挂起（挂起后 SDK 不再自动重连）
     */
    fun onClosedAfter(survivedMs: Long, healthy: Boolean): Boolean {
        hadAnyClose = true
        if (healthy) {
            // 健康会话正常关闭（QQ 网关例行踢线）：视为已成功过，计数清零，
            // SDK 3 秒后的自动重连按第 1 次重新计
            onHealthySession()
            return false
        }
 // 短命会话标记（下一条会话 READY 时不立即宣告成功，防抖）
        lastSessionShort = true
        val n = attempt.get()
        if (n < SMALL_RETRY_MAX) {
            // 未到上限：SDK 会自动重连，下一次 onOpen 计第 n+1 次
            if (notifyEnabled() && n >= SMALL_RETRY_MAX - 1) {
                // 最后一次机会：提示这轮快用完了（仅文件留档不刷控制台）
                PluginFileLog.write("[重连] 本轮重试已用 $n/$SMALL_RETRY_MAX 次，即将进行最后一次自动重连")
            }
            return false
        }
        giveUpAutoReconnect()
        return true
    }

    /**
     * 重连超时：挂起 SDK 自动重连，输出不可关闭的恢复指引，
     * 并调度 30 分钟后的下一轮（最多 [BIG_ROUND_MAX] 轮）。
     */
    private fun giveUpAutoReconnect() {
        if (suspended) return
        suspended = true
        val myGen = generation.incrementAndGet()
        val nextRound = bigRound.incrementAndGet()

        // —— 不可关闭的失败提示（用户明确要求：重试失败的重连指引不能关） ——
        val builder = StringBuilder()
        builder.append("[重连] QQ 机器人已连续 $SMALL_RETRY_MAX 次重连失败（重连超时），已暂停自动重连。")
        builder.append(" 可在服务器内使用指令 /hbkrg chs 立即重新尝试连接。")
        if (nextRound <= BIG_ROUND_MAX) {
            val minutes = BIG_BACKOFF_MILLIS / 60000
            builder.append("未手动干预时，$minutes 分钟后将自动进行下一轮重试（第 $nextRound/$BIG_ROUND_MAX 轮，每轮 $SMALL_RETRY_MAX 次）。")
        } else {
            builder.append("自动重试的 $BIG_ROUND_MAX 轮已全部用尽，此后需要使用 /hbkrg chs 手动恢复。")
        }
        PluginFileLog.errorAndKeep(builder.toString())
 // 手动重连触发的一轮里，超时结果同步发 QQ 群（之后本轮回显结束）
        announceToGroup(builder.toString())
        announceToGroups = false

        // 关闭 SDK 自动重连 + 断开当前 socket（给 QQ 网关降温）
        suspendConnection()

        // 30 分钟退避后自动恢复（最后一轮之后不再恢复，等待 /hbkrg chs）
        if (nextRound <= BIG_ROUND_MAX) {
            scheduleBackoffWake(myGen, nextRound)
        }
    }

    /**
     * 挂起连接：关闭 SDK 自动重连并断开当前 socket。
     *
     * - anyCloseReconnect=false → SDK 不再自行重连（未归类关闭码）；
     * - 主动断开 socket → 看门狗/兑底重连均凭 [isSuspended] 停连。
     */
    private fun suspendConnection() {
        try {
            QClient.starter?.config?.anyCloseReconnect = false
        } catch (_: Throwable) {
        }
        try {
            QClient.starter?.wssWorker?.webSocket?.close()
        } catch (_: Throwable) {
        }
    }

    /** 调度退避结束后的自动恢复（旧线程凭代际号自动失效）。 */
    private fun scheduleBackoffWake(myGen: Int, round: Int) {
        val thread = Thread({
            try {
                Thread.sleep(BIG_BACKOFF_MILLIS)
            } catch (_: InterruptedException) {
                return@Thread
            }
            // 期间发生过手动重试或重新挂起：本线程作废
            if (generation.get() != myGen || !suspended) return@Thread
 // 新一轮开始——清零小轮计数（旧版沿用上一轮 attempt，
            // 退避恢复后提示「第 6/5 次」超出上限显示）
            attempt.set(0)
            successAnnounced = false
            PluginFileLog.warnAndKeep(
                "[重连] 30 分钟退避结束，开始第 $round/$BIG_ROUND_MAX 轮自动重试（每轮 $SMALL_RETRY_MAX 次）"
            )
            QClient.resumeConnection()
        }, "qq-reconnect-backoff").apply { isDaemon = true }
        thread.start()
    }

    /**
     * 手动重连（/hbkrg chs）：重置全部计数，立即恢复连接。
     *
 * 本轮关键里程碑同步发到配置的 QQ 群（在群里远程执行重连时
     * 过程可见，不必盯控制台；自动重连不广播）。
     *
     * @return 给命令发送者的结果文本
     */
    fun manualReconnect(): String {
        generation.incrementAndGet()
        val wasSuspended = suspended
        val usedRound = bigRound.get()
        attempt.set(0)
        bigRound.set(0)
        suspended = false
        successAnnounced = false
 // 开启本轮 QQ 群过程回显
        announceToGroups = true
        val launched = QClient.resumeConnection()
        return if (launched) {
            if (wasSuspended) {
                "已重置重连计数（此前已完成 $usedRound 轮退避）并开始重新连接，过程与结果将发送到配置的 QQ 群"
            } else {
                "已开始重新连接，过程与结果将发送到配置的 QQ 群（同时见控制台）"
            }
        } else {
            announceToGroups = false
            "QQ 客户端未启动（未配置 bot.app-id / bot.secret 或插件已停用），无法重连"
        }
    }

    /** 重试过程提示是否开启（bot.reconnect-notify，默认 true；失败指引不受此开关控制）。 */
    private fun notifyEnabled(): Boolean {
        return try {
            val instance = cn.kerong.bot.provider.BotShared.instance
            (instance as? org.bukkit.plugin.java.JavaPlugin)
                ?.config?.getBoolean("bot.reconnect-notify", true) ?: true
        } catch (_: Throwable) {
            true
        }
    }
}

/**
 * 回复序号守卫：修复 QQ 官方接口 40054005「消息被去重」。
 *
 * ## 根因
 *
 * QQ 群机器人被动回复的去重键是（msg_id, msg_seq）：同一条群消息（msg_id）的
 * 多条回复必须使用互不相同的 msg_seq。SDK（kloping）在事件对象内维护自增序号
 * （初始为 1），但 **QQ 网关在弱网 / 会话恢复时会重投递同一条消息**（at-least-once），
 * SDK 为重投递的消息创建全新事件对象——序号又从 1 开始。此时第二条回复的
 * msg_seq 与第一条完全相同，被平台按「重复消息」拒收：
 * `HTTP 400 code=40054005 {"message":"消息被去重，请检查请求msgseq"}`。
 * 典型受影响场景：分页渲染的多张图片（第二张起全部被去重）、重投递后的任何回复。
 *
 * ## 修复
 *
 * 每条群消息到达（[GroupMessageHandler] 入口）时，按 msg_id 为本次投递分配一个
 * **互不重叠的序号基数**并写入事件对象（SDK 的 setMsgSeq）：
 * - 第 1 次投递：基数 1（与旧行为一致，msg_seq 从 1 开始递增）；
 * - 第 N 次重投递：基数 1 + (N-1)×100000——同一条消息的任何两次投递、
 *   任意次回复的 msg_seq 绝不重复；
 * - 计数按 msg_id 隔离、30 分钟未活跃自动清理（QQ 被动回复的判定窗口约 5 分钟，
 *   远小于清理周期），内存占用可忽略。
 */
object ReplySeqGuard {

    /** 同一 msg_id 两次投递的基数间隔（保证任何回复序号永不重叠）。 */
    private const val BASE_STRIDE = 100_000L

    /** 条目清理周期与保留时长（毫秒）。 */
    private const val CLEANUP_INTERVAL_MS = 10L * 60L * 1000L
    private const val RETAIN_MS = 30L * 60L * 1000L

    /** msg_id →（已投递次数, 最近活跃时间）。 */
    private class DeliveryCounter(@Volatile var count: Long, @Volatile var lastAt: Long)

    private val counters = ConcurrentHashMap<String, DeliveryCounter>()

    @Volatile
    private var lastCleanupAt = 0L

    /**
     * 为本次消息投递分配序号基数（写入 SDK 事件对象的 seq 字段，
     * 后续该事件的所有回复按基数、基数+1、基数+2… 递增，SDK 自增语义保持不变）。
     */
    fun allocateBase(msgId: String?): Int {
        val key = msgId?.takeIf { it.isNotEmpty() } ?: return 1
        val now = System.currentTimeMillis()
        maybeCleanup(now)
        val counter = counters.computeIfAbsent(key) { DeliveryCounter(0, now) }
        synchronized(counter) {
            counter.count += 1
            counter.lastAt = now
            val base = 1L + (counter.count - 1) * BASE_STRIDE
            return base.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
    }

    /** 惰性清理过期条目（低频，无后台线程；volatile 时间戳限频）。 */
    private fun maybeCleanup(now: Long) {
        if (now - lastCleanupAt < CLEANUP_INTERVAL_MS) return
        lastCleanupAt = now
        val iterator = counters.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.lastAt > RETAIN_MS) iterator.remove()
        }
    }
}
