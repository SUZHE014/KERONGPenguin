package cn.kerong.bot.datapack

/**
 * 命令解析结果：成功时携带命令文本，失败时携带错误原因。
 */
data class ResolvedCommand(
    val command: String? = null,
    val error: String? = null,
)

/**
 * 持久化的群命令设置快照。
 *
 * 1.7.5 覆盖第三轮：群级全量转发开关（fullForwarding）已删除——全量转发
 * 只按总配置 features.full-amount 生效，不再按群记忆。
 */
data class StoredCommandSettings(
    val administrators: Map<String, Set<String>> = emptyMap(),
    val authenticatedUsers: Map<String, Set<String>> = emptyMap(),
    val administratorModes: Map<String, AdministratorAccessMode> = emptyMap(),
)
